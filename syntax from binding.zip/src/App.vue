<template>
  <input type="text"
v-model="message"/>
  <p>Pesan: {{ message }}</p>
</template>

<script>
export default{
  data(){
    return{
      message:"",
    };
  },
};
</script>