<template>
  <img :src="imageUrl" />
</template>

<script>
export default {
  data() {
    return {
      imageUrl : 'https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Thresh_0.jpg',
    };
  },
};
</script>