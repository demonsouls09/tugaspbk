<template>
  <p>Pesan: {{message}}</p>
  <p>Hasil: {{angka1 + angka2}}</p>
</template>

<script>
export default{
  data() {
    return{
      message:'halo pak',
      angka1:20,
      angka2:30,
    };
  },
};
</script>