<template>
  <p>count: {{count}}</p>
  <p>message: {{message}}</p>
  <p>Name: {{data.Name}}, Age: {{data.Age}}</p>
  <button @click="count++">increment</button>
</template>

<script>
import { ref } from 'vue';

export default {
  setup(){
    const count = ref(0);
    const message = ref('Hallo, jay!');
    const data = ref({ name: 'Darius',age:30 })

    return {
      count,
      message,
      data,
    };
  },
}
</script>