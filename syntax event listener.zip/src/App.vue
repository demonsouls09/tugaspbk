<template>
  <button @click="handleClick">Klik yang ini</button>
</template>

<script>
export default{
  methods:{
    handleClick(){
      alert('tombol sudah di kilik ya!');
    }
  }
};
</script>