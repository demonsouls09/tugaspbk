<template>
  <p v-if="isLoggedIn">selamat datang!</p>
</template>

<script>
export default{
  data(){
    return{
      isLoggedIn: true,
    };
  },
};
</script>